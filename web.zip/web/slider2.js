const appPictures = document.querySelector(".offer-pictures").children;
var appPicturesCount = appPictures.length;






for (let i=0; i < appPicturesCount; i++) {
    appPictures[i].onclick = function() {
      if (appPictures[i].classList.contains("img-clicked")) {
        appPictures[i].classList.remove("img-clicked");
      } else {
        appPictures[i].classList.add("img-clicked")
      }
    }
  }





var index = 0;
var jumpWidth = 0;


const slider = document.querySelector(".slider-container");

const sliderItems = slider.querySelector(".slider-items").children;

const totalSlides = sliderItems.length;

const containerWidth = slider.offsetWidth;

const nextSlide = slider.querySelector(".next-slide");
const prevSlide = slider.querySelector(".prev-slide");

nextSlide.onclick = function() {
  next();
}

prevSlide.onclick = function() {
  prev();
}

setWidth();

function setWidth() {
  var totalWidth = 0;
    for(let i=0; i<sliderItems.length; i++) {
      sliderItems[i].style.width = containerWidth + "px";
      totalWidth = totalWidth + containerWidth;
    }
    slider.querySelector(".slider-items").style.width = totalWidth + "px";
}

function next() {
  if(index == totalSlides-1) {
    index = 0;
    jumpWidth = 0;
  }

  else {
    index++;
    jumpWidth = jumpWidth+containerWidth;
  }
  slider.querySelector(".slider-items").style.marginLeft = -jumpWidth + "px";
}

function prev() {
  if(index == 0) {
    index = totalSlides-1;
    jumpWidth = containerWidth*(totalSlides-1);
  }

  else {
    index--;
    jumpWidth = jumpWidth-containerWidth;
  }
  slider.querySelector(".slider-items").style.marginLeft = -jumpWidth + "px";
}


// A function to toggle the images
function toggleImages(id1, id2, id3) {
  // Get the image elements by id
  var image1 = document.getElementById(id1);
  var image2 = document.getElementById(id2);
  var image3 = document.getElementById(id3);

  // Hide all the images
  var images = document.getElementsByClassName("image");
  for (var i = 0; i < images.length; i++) {
    images[i].style.display = "none";
  }

  // Toggle the display of the images
  image1.style.display = image1.style.display === "none" ? "block" : "none";
  image2.style.display = image2.style.display === "none" ? "block" : "none";
  image3.style.display = image3.style.display === "none" ? "block" : "none";
}

const questionDivs = document.querySelector(".accordion").children;
const questionTitles = document.getElementsByClassName("question-title");

for (let i=0; i < questionDivs.length; i++) {
  questionTitles[i].onclick = function() {
    if(questionDivs[i].classList.contains("question-open")) {
      questionDivs[i].classList.toggle("question-open");
      questionTitles[i].classList.toggle("question-title-active");
    } else {
      questionDivs[i].classList.toggle("question-open");
      questionTitles[i].classList.toggle("question-title-active");
    }
  }
}